/*
 * sdfats.c
 *
 *  Created on: 10-Jun-2020
 *      Author: S.Pairot
 */

#define SRC_SDFATS_C

/* Includes ------------------------------------------------------------------*/

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include "global.h"
#include "typedef.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
int8_t T10ms_SamplingRate;
msg_t sdfat_msg;

/* USER CODE BEGIN Private defines */

/**
* @brief Function implementing the SD Fats initial process
* @param argument: Not used
* @retval None
*/
void SDFATs_init(void) {
    memset(&swrt_buf[0],0x00,sizeof(swrt_buf));
}

/**
* @brief Function implementing the SD Fats API
* @param argument: Not used
* @retval None
*/
void SDFATs_rx_msg(pt_msg_t Lpt_msg) {
    switch (Lpt_msg->id) {
    case MSG_RES_SWRT_DATA:
    	if (Lpt_msg->sender == C_ADDR_UART) {
          // SD card save data here
    	}
    	break;
    default:
    	break;
    }
}

/**
* @brief Function implementing the SD Fats API
* @param argument: Not used
* @retval None
*/
void SDFATs_tx_msg(uint8_t L_msgid) {
    if (L_msgid == MSG_REQ_SWRT_DATA) {
    	sdfat_msg.receiver = C_ADDR_UART;
    }
    sdfat_msg.id = L_msgid;
	sdfat_msg.sender = C_ADDR_SDFAT;
	Main_req_msg(&sdfat_msg);
}

/**
* @brief Function implementing the SD Fats main process
* @param argument: Not used
* @retval None
*/
void SDFATs_main(void) {
	if (T10ms_SamplingRate < 1) {
		SDFATs_tx_msg(MSG_REQ_SWRT_DATA);
	    T10ms_SamplingRate = 500/10;  // Reload Sampling data every 500 ms
	}
}

/**
  * @brief  SD Fat 10ms interval timer
  * @param  None
  * @retval None
  */
void SDFATs_ShortTimer(void) {
    if (T10ms_SamplingRate > 0)
    	T10ms_SamplingRate--;
}
/* USER CODE END Private defines */
