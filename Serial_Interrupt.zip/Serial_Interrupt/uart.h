/*
 * uart.h
 *
 * Created: 14/03/2017 11:11:46
 *  Author: Jonathan
 */ 


#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <avr/interrupt.h>
//#include <util/setbaud.h>
#include "ring_buffer.h"

#define		Uart_EnableTransmitIT()		UCSR0B |= (1<<UDRIE0)
#define		Uart_DisableTransmitIT()	UCSR0B &= ~(1<<UDRIE0)


void		Uart_init();
void		Uart_Transmit_IT(unsigned char *data, unsigned char nbytes);


ring_buffer_t rb_tx;

void Uart_init()
{
  UBRR0H = 0/*UBRRH_VALUE*/;
  UBRR0L = 8/*UBRRL_VALUE*/;
  UCSR0B = 1<<RXEN0 | 1<<TXEN0;
  UCSR0C = 1<<UCSZ00 | 1<< UCSZ01;
  
  RB_init(&rb_tx);
}

void Uart_Transmit_IT( unsigned char *data, unsigned char nbytes )
{
  RB_write(&rb_tx, data, nbytes);
  Uart_EnableTransmitIT();
}


ISR(USART_UDRE_vect)
{
  if (RB_length(&rb_tx) > 0)
  {   
    UDR0 = RB_readByte(&rb_tx);
  } 
  else
  {
    Uart_DisableTransmitIT();
  }
}

#endif /* UART_H_ */
