/*
 * uart.c
 *
 *  Created on: 10-Jun-2020
 *      Author: S.Pairot
 */
#define SRC_UART_C

/* Includes ------------------------------------------------------------------*/

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include "global.h"
#include "typedef.h"
#include "UartRingbuffer.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define V_RX_BUF_SIZE   (150)
#define V_RX_DAT_LEN    (127)

typedef enum {
	V_RX_STATE_INIT = 0,
	V_RX_STATE_START,
	V_RX_STATE_DATA,
	V_RX_STATE_CHKSUM,
	V_RX_STATE_FINISH,
	V_RX_STATE_ERROR
} Rx_State;

typedef enum {
	V_RX_STS_NONE = 0,
	V_RX_STS_SUCCESS,
	V_RX_STS_FAILURE,
	V_RX_STS_ERR_CHKSUM,
	V_RX_STS_ERR_TIMOUT,
	V_RX_STS_ERR_OVERFLOW
} Rx_Status;

typedef struct {
	uint8_t Header[2];
	uint8_t PacketLen;
	uint8_t Data[V_RX_BUF_SIZE];
	uint8_t ChkSum;
} Rx_Packet_t, *Pt_Rx_Packet_t;

// Flag define
union V1 uart_flag;
  #define F_req_data    uart_flag.b.b0

Rx_Packet_t rx_buf;
Rx_State rx_state;
Rx_Status rx_sts;
uint8_t count_data;
uint8_t count_header;
msg_t uart_msg;
/* USER CODE BEGIN Private defines */

/**
* @brief Function implementing the UART initial process
* @param argument: Not used
* @retval None
*/
void UART1_init(void) {
	 Ringbuf_init();                           // Initial ring buffer
	 memset(&rx_buf, 0x00, sizeof(rx_buf));    // Clear uart rx buffer
	 rx_state = V_RX_STATE_INIT;               // Initial rx state
	 rx_sts = V_RX_STS_NONE;                   // Initial rx status
	 count_data = 0;                           // Count data
	 count_header = 0;                         // Count header
}

/**
* @brief Function implementing the UART API for Received message
* @param argument: Not used
* @retval None
*/
void UART1_rx_msg(pt_msg_t Lpt_msg) {           //
    switch(Lpt_msg->id) {                       // Check message id
    case MSG_REQ_SWRT_DATA:                     // Message request SWRT data
    	if (Lpt_msg->sender == C_ADDR_SDFAT) {  // Send request from SD Fat task
    		F_req_data = ON;                    // Set request flag
    	}                                       //
    	break;                                  //
    default:                                    //
    	break;                                  //
    }                                           //
}                                               //

/**
* @brief Function implementing the UART API for transmitted message
* @param argument: Not used
* @retval None
*/
void UART1_tx_msg(uint8_t L_msgid) {
    if (L_msgid == MSG_RES_SWRT_DATA) {         // Response swrt data
    	uart_msg.receiver = C_ADDR_SDFAT;       // Receiver is SDFAT task
    }                                           //
	uart_msg.id = L_msgid;                      // set message id
	uart_msg.sender = C_ADDR_UART;              // set sender
	Main_req_msg(&uart_msg);                    // request message
}

/**
* @brief Function implementing the UART check sum
* @param argument: pointer to buffer, data length
* @retval sum of data
*/
uint8_t UART1_ChkSum(uint8_t *Lpt_data, uint8_t L_Len) {
	uint8_t L_Sum = 0;
	do {
		L_Sum -= *Lpt_data;
		++Lpt_data;
	} while(--L_Len);

	return (L_Sum);
}
/**
* @brief Function implementing the UART Receive data
* @param argument: Not used
* @retval None
*/
void UART1_RecvByte(void) {
    uint8_t L_data;
    L_data = Uart_read();

    switch(rx_state) {
        case V_RX_STATE_INIT:
        case V_RX_STATE_START:
        	if (L_data == 0xF8) {                                // Header check 0xF8, 0xF8
        		rx_buf.Header[count_header++] = L_data;          //
        		if (count_header >= 2) {                         // Count header finished
        			rx_buf.PacketLen = V_RX_DAT_LEN;             //
        			rx_state = V_RX_STATE_DATA;                  //
        			count_header = 0;                            //
        			count_data = 0;                              //
        		}                                                //
        	}                                                    //
        	break;                                               //
        case V_RX_STATE_DATA:
        	rx_buf.Data[count_data++] = L_data;                   // Copy data
        	if (count_data >= V_RX_BUF_SIZE) {                    // Buffer overflow?
        		rx_sts = V_RX_STS_ERR_OVERFLOW;                   //
        		rx_state = V_RX_STATE_ERROR;                      //
        	} else if (count_data >= rx_buf.PacketLen) {          // Copy data finished?
        		rx_state = V_RX_STATE_CHKSUM;                     //
        	}                                                     //
    	    break;                                                //
        case V_RX_STATE_CHKSUM:
        	if (!UART1_ChkSum(&rx_buf.Data[0], rx_buf.PacketLen)) { // check sum OK?
         		rx_sts = V_RX_STS_SUCCESS;
            	rx_state = V_RX_STATE_FINISH;
        	} else {
         		rx_sts = V_RX_STS_ERR_CHKSUM;
            	rx_state = V_RX_STATE_ERROR;
        	}
        	break;
        default:
    	    break;
    }
}

/**
* @brief Function implementing the UART main process
* @param argument: Not used
* @retval None
*/
void UART1_main(void) {
	if (rx_state == V_RX_STATE_FINISH) {                             // Received data finished?
		if (F_req_data) {                                            // Request data?
			memcpy(&swrt_buf[0], &rx_buf.Data[0], V_RX_DAT_LEN-1);   // Transfer data to other buffer0
            UART1_tx_msg(MSG_RES_SWRT_DATA);                         // Notify message
			F_req_data = OFF;                                        // Clear request flag
		}
		rx_state = V_RX_STATE_START;
	} else if (rx_state == V_RX_STATE_ERROR) {
		rx_state = V_RX_STATE_START;
	}

    while (IsDataAvailable()) {                                      // rx data are available now?
    	UART1_RecvByte();                                            // uart receive byte
    }
}

/**
  * @brief  UART 10ms interval timer
  * @param  None
  * @retval None
  */
void UART1_ShortTimer(void) {

}
/* USER CODE END Private defines */
