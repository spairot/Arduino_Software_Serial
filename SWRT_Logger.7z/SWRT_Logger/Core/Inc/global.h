/*
 * global.h
 *
 *  Created on: Feb 23, 2020
 *      Author: Pairot_PC
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_

/* Includes ------------------------------------------------------------------*/

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f4xx_hal.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
UART_HandleTypeDef huart1;

typedef struct {
	uint8_t id;                        // Message ID
	uint8_t sender;                    // Task sender
	uint8_t receiver;                  // Receiver task
	uint8_t *pt_msg;                   // Message pointer
	uint8_t msg[5];                    // Message buffer
} msg_t, *pt_msg_t;

uint8_t swrt_buf[128];
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

#define C_ADDR_UART          (0x10)
#define C_ADDR_SDFAT         (0x20)
#define C_ADDR_KEY           (0x30)
#define C_ADDR_DISP          (0x40)

#define MSG_REQ_SWRT_DATA    (0x21)
#define MSG_RES_SWRT_DATA    (0x22)

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/

/* USER CODE BEGIN EFP */
#undef	EXTR
#ifdef	SRC_MAIN_C
#define EXTR
#else
#define EXTR	extern
#endif
EXTR void Main_req_msg(pt_msg_t);

#undef	EXTR
#ifdef	SRC_UART_C
#define EXTR
#else
#define EXTR	extern
#endif
EXTR void UART1_init(void);
EXTR void UART1_main(void);
EXTR void UART1_ShortTimer(void);
EXTR void UART1_rx_msg(pt_msg_t);

#undef	EXTR
#ifdef	SRC_SDFATS_C
#define EXTR
#else
#define EXTR	extern
#endif
EXTR void SDFATs_init(void);
EXTR void SDFATs_main(void);
EXTR void SDFATs_ShortTimer(void);
EXTR void SDFATs_rx_msg(pt_msg_t);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */



#endif /* INC_GLOBAL_H_ */
