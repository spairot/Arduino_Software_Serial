/*
 * global.h
 *
 *  Created on: Feb 23, 2020
 *      Author: Pairot_PC
 */

#ifndef INC_TYPEDEF_H_
#define INC_TYPEDEF_H_

/* Includes ------------------------------------------------------------------*/

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
#define ON                   (1)
#define OFF                  (0)

#define MBS(x)               (1 << (x))
#define MBR(x)              ˞~(1 << (x))


/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */
struct B8 { 							// Bit field8
	uint8_t b0	:1; 					// bit0
	uint8_t b1	:1; 					// bit1
	uint8_t b2	:1; 					// bit2
	uint8_t b3	:1; 					// bit3
	uint8_t b4	:1; 					// bit4
	uint8_t b5	:1; 					// bit5
	uint8_t b6	:1; 					// bit6
	uint8_t b7	:1; 					// bit7
};										//

struct N8 { 							// Nibble field8
	uint8_t n0	:4; 					//
	uint8_t n1	:4; 					//
};										//

union V1 {								// For 8 bit variable
	uint8_t uc;							//
	int8_t  sc;							//
	struct N8 n;						//
	struct B8 b;						//
};										//
/* USER CODE END Private defines */



#endif /* INC_TYPEDEF_H_ */
